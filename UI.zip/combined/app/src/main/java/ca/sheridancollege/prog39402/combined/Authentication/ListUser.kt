package ca.sheridancollege.prog39402.combined.Authentication

data class ListUser( val text1: String)
